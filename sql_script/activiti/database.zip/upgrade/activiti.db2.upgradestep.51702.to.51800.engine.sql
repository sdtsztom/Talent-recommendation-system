update ACT_GE_PROPERTY set VALUE_ = '5.18.0.0' where NAME_ = 'schema.version';
