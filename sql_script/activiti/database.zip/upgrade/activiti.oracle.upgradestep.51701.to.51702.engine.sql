update ACT_GE_PROPERTY set VALUE_ = '5.17.0.2' where NAME_ = 'schema.version';
	
